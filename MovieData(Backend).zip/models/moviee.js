const mongoose=require("mongoose")
let Schema=mongoose.Schema

const MoviesData=new Schema({
    movieName:{
       type:String,
       minLength:3,
       maxLength:15,
       required:true
    },
    movieDesc:{
        type:String,
        minLength:3,
        maxLength:20,
        required:true
     }
})
module.exports=mongoose.model("Movie",MoviesData)