let express=require("express")
let route=express.Router()
let userController=require("../controllers/movie")


route.get("/movie",userController.mData)
route.post("/add",userController.addMovieData)
route.delete("/delete",userController.deleteMovie)

module.exports=route