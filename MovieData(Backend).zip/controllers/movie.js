let moviee=require("../models/moviee")

let mData=async(req,res,next)=>{
    try {
        let movie = await moviee.find().lean()
        res.json({
            error:false,
            message:"All MovieData",
            data:movie
        })
    } catch (err) {
       next(err)
    }
}

let addMovieData=async(req,res,next)=>{
    let { movieName,movieDesc } = req.body
    try {
        await moviee.insertMany([{ movieName,movieDesc }])
        res.json({
            error:false,
            message:"Movie added successfully",
            data:{ movieName,movieDesc }
        })
    } catch (err) {
        next(err)
    }
}

let deleteMovie=async(req,res,next)=>{
    try {
        await moviee.deleteMany({ _id: req.body._id })
        res.json({
            error:false,
            message:"movieData deleted successfully",
            data:null
        })
    } catch (err){
        next(err)
    }
}

module.exports={
    mData,
    addMovieData,
    deleteMovie
}
