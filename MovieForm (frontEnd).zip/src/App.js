import logo from './logo.svg';
import './App.css';

import MovieData from './component/MovieData';

function App() {
  return (
    <div className="App">
    
     <MovieData/>

    </div>
  );
}

export default App;
